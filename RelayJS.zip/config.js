/*Power*/
module.exports = {
    botMode: 'live', // live or tester
    botNode: 'localnode',
    mongoURI: `mongodb+srv://sadri:sadri@cluster0.eyfridx.mongodb.net/`,
    dbName: `Relay`
};

// /*Pedro*/
// module.exports = {
//     token: 'MTI4ODUxMjkwODk2NzU0Mjg0NA.GLNxMN.vndA6vXnQEVcQTtpOt5C-1RNoLdiNwfqbgf4Ys',
//     clientId: '1288512908967542844',
//     mongoURI: `mongodb+srv://sadri:sadri@cluster0.eyfridx.mongodb.net/`,
//     dbName: `Relay`
// };